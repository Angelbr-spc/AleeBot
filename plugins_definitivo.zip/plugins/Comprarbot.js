const handler = async (m, {conn}) => {
  m.reply(global.ComprarBot);
};
handler.command ='comprarbot',/^(ComprarBot|Comprar|comprar|ComprarBot)$/i;
export default handler;

global.ComprarBot = `
〔 *𝐁𝐨𝐭 𝐀𝐥𝐞𝐞𝐁𝐨𝐭 👑- Ai* 〕

*BOT PARA GRUPO* :
> wa.me/584246582666

*BOT PERZONALIZADO* :
> wa.me/584246582666
`;